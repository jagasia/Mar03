import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class Main2 {

	public static String encryptSha1(String password) throws NoSuchAlgorithmException
	{
		//String password = "123456";
	        MessageDigest md = MessageDigest.getInstance("SHA-256");
	        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
			// bytes to hex
	        StringBuilder sb = new StringBuilder();
	        for (byte b : hashInBytes) {
	            sb.append(String.format("%02x", b));
	        }
	        //System.out.println(sb.toString());
		return sb.toString();
	}
	public static void main(String[] args) throws NoSuchAlgorithmException {
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		if(encryptSha1(input).equals("2b217fd26f0506d7cfe87e08483838fe8bf130ce6b3a987d94adfd3d043454a5"))
			System.out.println("Login is successful");
		else
			System.out.println("Login is failed");
	}

}
